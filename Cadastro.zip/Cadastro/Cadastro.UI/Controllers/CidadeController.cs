﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Cadastro.Aplicacao;
using Cadastro.Dominio;

namespace Cadastro.UI.Controllers
{
    public class CidadeController : Controller
    {
        // GET: Cidade
        public ActionResult Index()
        {
            var app = new CidadeAplicacao();
            var lista = app.ListarCidade();
            return View(lista);
        }

        public ActionResult CadastrarCidade()
        {
           
                return View();
            

        }

        [HttpPost]
        public  ActionResult CadastrarCidade(Cidade cidade)
        {
            if(ModelState.IsValid)
            {
                var app = new CidadeAplicacao();
                app.Inserir(cidade);
                
            }
            return RedirectToAction("Index", "Cidade");

        }

        
    }
}